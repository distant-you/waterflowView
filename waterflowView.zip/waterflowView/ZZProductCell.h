//
//  ZZProductCell.h
//  waterflowView
//
//  Created by parrow tech on 16/1/15.
//  Copyright © 2016年 YX. All rights reserved.
//

#import "ZZWaterflowViewCell.h"
@class ZZWaterflowView, ZZProduct;

@interface ZZProductCell : ZZWaterflowViewCell

@property (nonatomic, strong) ZZProduct *product;

+ (ZZProductCell *)cellWithWaterflowView:(ZZWaterflowView *)waterflowView;



@end
