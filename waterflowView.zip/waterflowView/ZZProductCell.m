//
//  ZZProductCell.m
//  waterflowView
//
//  Created by parrow tech on 16/1/15.
//  Copyright © 2016年 YX. All rights reserved.
//

#define ZZPriceLabelH 25

#import "ZZProductCell.h"
#import "ZZWaterflowView.h"
#import "UIImageView+WebCache.h"
#import "ZZProduct.h"

@interface ZZProductCell ()

@property (nonatomic, weak) UIImageView *picView;

@property (nonatomic, weak) UILabel *priceLabel;

@end

@implementation ZZProductCell

+ (ZZProductCell *)cellWithWaterflowView:(ZZWaterflowView *)waterflowView
{
    static NSString *ID = @"cell";
    ZZProductCell *cell = [waterflowView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[ZZProductCell alloc] init];
        cell.identifier = ID;
    }
    return cell;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        UIImageView *picView = [[UIImageView alloc] init];
        self.picView = picView;
        [self addSubview:picView];
        
        UILabel *priceLabel = [[UILabel alloc] init];
        self.priceLabel = priceLabel;
        self.priceLabel.textColor = [UIColor whiteColor];
        self.priceLabel.textAlignment = NSTextAlignmentCenter;
        self.priceLabel.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.5];
        [self addSubview:priceLabel];
    }
    return self;
}

- (void)setProduct:(ZZProduct *)product
{
    _product = product;
    
    // 设置数据
    [self.picView sd_setImageWithURL:[NSURL URLWithString:product.img] placeholderImage:[UIImage imageNamed:@"loading"]];
    self.priceLabel.text = product.price;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.picView.frame = self.bounds;
    self.priceLabel.frame = CGRectMake(0, self.frame.size.height - ZZPriceLabelH, self.frame.size.width, ZZPriceLabelH);
}



@end
