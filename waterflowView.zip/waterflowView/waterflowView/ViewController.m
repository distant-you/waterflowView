//
//  ViewController.m
//  waterflowView
//
//  Created by parrow tech on 16/1/12.
//  Copyright © 2016年 YX. All rights reserved.
//

#import "ViewController.h"
#import "ZZWaterflowView.h"
#import "MJExtension.h"
#import "ZZProduct.h"
#import "ZZProductCell.h"
#import "MJRefresh.h"

@interface ViewController () <ZZWaterflowViewDataDelegate, ZZWaterflowViewDataSource>

@property (nonatomic, strong) NSMutableArray *products;

@property (nonatomic, weak) ZZWaterflowView *waterflowView;

@end

@implementation ViewController

- (NSMutableArray *)products
{
    if (_products == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"1.plist" ofType:nil];
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:path];
        _products = [ZZProduct mj_objectArrayWithKeyValuesArray:dictArray];
    }
    return _products;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    ZZWaterflowView *waterflowView = [[ZZWaterflowView alloc] init];
    self.waterflowView = waterflowView;
    waterflowView.frame = self.view.bounds;
    [self.view addSubview:waterflowView];
    waterflowView.waterDataSource = self;
    waterflowView.waterDelegate = self;
    
    self.waterflowView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    self.waterflowView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    
    
}

/**
 *  加载新数据
 */
- (void)loadNewData
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        // 停止刷新
        [self.waterflowView.mj_header endRefreshing];
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"2.plist" ofType:nil];
        NSArray *newDataArray = [ZZProduct mj_objectArrayWithFile:path];
        
        NSMutableArray *tempArray = [NSMutableArray array];
        [tempArray addObjectsFromArray:newDataArray];
        [tempArray addObjectsFromArray:self.products];
        self.products = tempArray;
        
        // 刷新数据
        [self.waterflowView reloadData];
    });
}

/**
 *  下拉加载更多数据
 */
- (void)loadMoreData
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        // 停止刷新
        [self.waterflowView.mj_footer endRefreshing];
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"3.plist" ofType:nil];
        NSArray *newDataArray = [ZZProduct mj_objectArrayWithFile:path];
        [self.products addObjectsFromArray:newDataArray];
        
        // 刷新数据
        [self.waterflowView reloadData];
    });
}

#pragma mark - waterflowView dataSource
- (NSUInteger)numberOfCellsInWaterflowView:(ZZWaterflowView *)waterflowView
{
    return self.products.count;
}

- (ZZWaterflowViewCell *)waterflowView:(ZZWaterflowView *)waterflowView cellAtIndex:(NSInteger)index
{
    ZZProductCell *cell = [ZZProductCell cellWithWaterflowView:waterflowView];
    cell.product = self.products[index];
    cell.backgroundColor = [UIColor colorWithRed:(arc4random() % 256) / 255.0 green:(arc4random() % 256) / 255.0 blue:(arc4random() % 256) / 255.0 alpha:1.0];
    return cell;
}

#pragma mark - waterflowView delegate

- (CGFloat)waterflowView:(ZZWaterflowView *)waterflowView marginType:(ZZWaterflowViewMarginType)type
{
    switch (type) {
        case ZZWaterflowViewMarginTypeRow:
            return 5;
            break;
        case ZZWaterflowViewMarginTypeColumn:
            return 5;
            break;
        case ZZWaterflowViewMarginTypeRight:
            return 10;
            break;
        case ZZWaterflowViewMarginTypeLeft:
            return 10;
            break;
        default:
            return 20;
            break;
    }
}

- (CGFloat)waterflowView:(ZZWaterflowView *)waterflowView heightForRowAtIndex:(NSInteger)index
{
    ZZProduct *product = self.products[index];
    return product.h.floatValue / product.w.floatValue * [waterflowView cellWidth];
}

- (void)waterflowView:(ZZWaterflowView *)waterflowView didSelectCellAtIndex:(NSInteger)index
{
    NSLog(@"点击了第%zd个cell", index);
}

@end
