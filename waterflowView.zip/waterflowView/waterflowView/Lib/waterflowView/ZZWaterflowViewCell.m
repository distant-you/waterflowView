//
//  ZZWaterflowViewCell.m
//  waterflowView
//
//  Created by parrow tech on 16/1/12.
//  Copyright © 2016年 YX. All rights reserved.
//

#import "ZZWaterflowViewCell.h"

@implementation ZZWaterflowViewCell

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
