//
//  ZZWaterflowView.h
//  waterflowView
//
//  Created by parrow tech on 16/1/12.
//  Copyright © 2016年 YX. All rights reserved.
//

typedef enum {
    ZZWaterflowViewMarginTypeTop,
    ZZWaterflowViewMarginTypeLeft,
    ZZWaterflowViewMarginTypeBottom,
    ZZWaterflowViewMarginTypeRight,
    ZZWaterflowViewMarginTypeColumn,
    ZZWaterflowViewMarginTypeRow
} ZZWaterflowViewMarginType;

#import <UIKit/UIKit.h>
#import "ZZWaterflowViewCell.h"

@class ZZWaterflowView;

@protocol ZZWaterflowViewDataSource <NSObject>
/**
 *  一共有多少个cell
 */
- (NSUInteger)numberOfCellsInWaterflowView:(ZZWaterflowView *)waterflowView;

/**
 *  返回index对应的cell
 */
- (ZZWaterflowViewCell *)waterflowView:(ZZWaterflowView *)waterflowView cellAtIndex:(NSInteger)index;
@end

@protocol ZZWaterflowViewDataDelegate <NSObject>
@optional
/**
 *  返回index位置的高度
 */
- (CGFloat)waterflowView:(ZZWaterflowView *)waterflowView heightForRowAtIndex:(NSInteger)index;

/**
 *  返回瀑布流的列数
 */
- (NSUInteger)numberOfColumnsInWaterflowView:(ZZWaterflowView *)waterflowView;

/**
 *  选中index对应的cell
 */
- (void)waterflowView:(ZZWaterflowView *)waterflowView didSelectCellAtIndex:(NSInteger)index;

/**
 *  返回cell之间的各种间距
 */
- (CGFloat)waterflowView:(ZZWaterflowView *)waterflowView marginType:(ZZWaterflowViewMarginType)type;
@end

@interface ZZWaterflowView : UIScrollView

/** 数据源 */
@property (nonatomic, weak) id<ZZWaterflowViewDataSource> waterDataSource;

/** 代理 */
@property (nonatomic, weak) id<ZZWaterflowViewDataDelegate> waterDelegate;


/**
 *  刷新数据(只要调用这个方法会重新调用数据源方法请求数据)
 */
- (void)reloadData;

/**
 *  返回一个可循环利用的cell
 */
- (id)dequeueReusableCellWithIdentifier:(NSString *)identifier;

/**
 *  返回cell的宽度
 */
- (CGFloat)cellWidth;

@end
