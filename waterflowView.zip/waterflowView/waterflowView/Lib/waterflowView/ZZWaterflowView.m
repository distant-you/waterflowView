//
//  ZZWaterflowView.m
//  waterflowView
//
//  Created by parrow tech on 16/1/12.
//  Copyright © 2016年 YX. All rights reserved.
//

// 首先要算出所有cell的frame 用一个数组装起来，之后从数组中取出，装入数据

#define ZZDefaultTotalColumns 3
#define ZZDefaultCellMargin 20
#define ZZScreenW [UIScreen mainScreen].bounds.size.width
#define ZZScreenH [UIScreen mainScreen].bounds.size.height

#import "ZZWaterflowView.h"

@interface ZZWaterflowView ()

/** 存放所有cell的frame */
@property (nonatomic, strong) NSMutableArray *cellFrames;

/** 正在显示的cell */
@property (nonatomic, strong) NSMutableDictionary *displayCells;

/** 可循环利用的cell */
@property (nonatomic, strong) NSMutableSet *reusebleCells;

@end


@implementation ZZWaterflowView

- (NSMutableArray *)cellFrames
{
    if (_cellFrames == nil) {
        _cellFrames = [NSMutableArray array];
    }
    return _cellFrames;
}

- (NSMutableDictionary *)displayCells
{
    if (_displayCells == nil) {
        _displayCells = [NSMutableDictionary dictionary];
    }
    return _displayCells;
}

- (NSMutableSet *)reusebleCells
{
    if (_reusebleCells == nil) {
        _reusebleCells = [NSMutableSet set];
    }
    return _reusebleCells;
}

- (void)willMoveToSuperview:(UIView *)newSuperview
{
    [self reloadData];
}

- (void)setWaterDataSource:(id<ZZWaterflowViewDataSource>)waterDataSource
{
    _waterDataSource = waterDataSource;
    
    [self reloadData];
}

- (void)setWaterDelegate:(id<ZZWaterflowViewDataDelegate>)waterDelegate
{
    _waterDelegate = waterDelegate;
    
    [self reloadData];
}

/**
 *  刷新数据
 */
- (void)reloadData
{
    // 清空数据
    [self.cellFrames removeAllObjects];
    [self.displayCells removeAllObjects];
    [self.reusebleCells removeAllObjects];
    [self.displayCells.allValues makeObjectsPerformSelector:@selector(removeFromSuperview)];

    // 总共的cell的个数
    NSUInteger totalNumber = [self.waterDataSource numberOfCellsInWaterflowView:self];
    
    // 总列数
    NSUInteger totalColumns = [self totalColumns];
    CGFloat maxY[totalColumns]; // 定义一个c语言数组保存每一列的最大y值
    for (NSInteger idx = 0; idx < totalColumns; idx++) { // 给每个最大y值附初始值
        maxY[idx] = 0.0;
    }
    
    // 各种间距
    CGFloat leftMargin = [self marginWithType:ZZWaterflowViewMarginTypeLeft];
    CGFloat columnMargin = [self marginWithType:ZZWaterflowViewMarginTypeColumn];
    CGFloat topMargin = [self marginWithType:ZZWaterflowViewMarginTypeTop];
    CGFloat rowMargin = [self marginWithType:ZZWaterflowViewMarginTypeRow];
    CGFloat bottomMargin = [self marginWithType:ZZWaterflowViewMarginTypeBottom];
    
    for (NSInteger idx = 0; idx < totalNumber; idx++) {
        
        CGFloat cellW = [self cellWidth];
        CGFloat cellH = [self cellHeightAtIndex:idx];
        NSInteger currentColumn = 0; // 当前应排在那一列(最短的一列)
        CGFloat shortestColumnOfMaxY = maxY[currentColumn]; // 当前这一列的最大的y值(最短的一列)
        
        for (NSInteger j = 1; j < totalColumns; j++) {// 遍历数组找出最大Y值的最小值
            if (maxY[j] < shortestColumnOfMaxY) {
                currentColumn = j;
                shortestColumnOfMaxY = maxY[j];
            }
        }

        CGFloat cellY = 0.0;
        if (shortestColumnOfMaxY == 0.0) {
            cellY = topMargin;
        } else {
            cellY = shortestColumnOfMaxY + rowMargin;
        }
        CGFloat cellX = leftMargin + (cellW + columnMargin) * currentColumn;

        CGRect cellFrame = CGRectMake(cellX, cellY, cellW, cellH);
        
        // 添加到数组
        [self.cellFrames addObject:[NSValue valueWithCGRect:cellFrame]];
        
        // 更新这一列的最大的y值
        maxY[currentColumn] = CGRectGetMaxY(cellFrame);
    }
    
    // 设置contentSize
    CGFloat contentH = maxY[0];
    for (int i = 1; i < totalColumns; i++) {
        if (contentH < maxY[i]) {
            contentH = maxY[i];
        }
    }
    self.contentSize = CGSizeMake(0, contentH + bottomMargin);
}

/**
 *  滚动时调用
 */
- (void)layoutSubviews
{ // 开始会调用，拖动时也会调用
    [super layoutSubviews];
    
    // 判断是否在屏幕上（根据frame）
    for (NSInteger idx = 0; idx < self.cellFrames.count; idx++) {
        CGRect frame = [self.cellFrames[idx] CGRectValue];
        
        ZZWaterflowViewCell *cell = [self.displayCells objectForKey:@(idx)];
        if ([self isInScreen:frame]) {
            if (cell == nil) {
                cell = [self.waterDataSource waterflowView:self cellAtIndex:idx];
                cell.frame = frame;
                [self addSubview:cell];
                
                // 将正在展示的cell存入缓存池，下次再调用次方法时先从缓存池中去如果没有再创建（这样就不会频繁创建cell导致闪频）
                [self.displayCells setObject:cell forKey:@(idx)];
            }

        } else {
            if (cell) {
                // 从字典中移除
                [self.displayCells removeObjectForKey:@(idx)];
                // 从scrollView中移除
                [cell removeFromSuperview];
                
                // 存入缓存池
                [self.reusebleCells addObject:cell];
            }

        }
    }
    
}

/**
 *  返回一个可循环利用的cell
 */
- (id)dequeueReusableCellWithIdentifier:(NSString *)identifier
{
    __block ZZWaterflowViewCell *reusebleCell = nil;
    [self.reusebleCells enumerateObjectsUsingBlock:^(ZZWaterflowViewCell *cell, BOOL * _Nonnull stop) {
        if ([cell.identifier isEqualToString:identifier]) { // 当时创建cell的时候有给cell绑定过一个标志
            reusebleCell = cell;
            *stop = YES; // 停止遍历
        }
    }];
    
    if (reusebleCell) {
        [self.reusebleCells removeObject:reusebleCell];
    }
    return reusebleCell;
}

/**
 *  点击cell产生的事件
 */
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (![self.waterDelegate respondsToSelector:@selector(waterflowView:didSelectCellAtIndex:)]) return;
    
    UITouch *touch = [touches anyObject];
    
    CGPoint point = [touch locationInView:self];
    
    [self.displayCells enumerateKeysAndObjectsUsingBlock:^(NSNumber *idx, ZZWaterflowViewCell *cell, BOOL * _Nonnull stop) {
        if (CGRectContainsPoint(cell.frame, point)) {
            [self.waterDelegate waterflowView:self didSelectCellAtIndex:idx.integerValue];
            *stop = YES;
        }
    }];
}

#pragma mark - 私有方法
/**
 *  判断是否在屏幕内
 */
- (BOOL)isInScreen:(CGRect)frame
{
    return (CGRectGetMaxY(frame) > self.contentOffset.y && CGRectGetMinY(frame) < (self.contentOffset.y + ZZScreenH));
}

/**
 *  返回cell的高度
 */
- (CGFloat)cellHeightAtIndex:(NSInteger)index
{
    if ([self.waterDelegate respondsToSelector:@selector(waterflowView:heightForRowAtIndex:)]) {
        return [self.waterDelegate waterflowView:self heightForRowAtIndex:index];
    } else {
        return [self cellWidth];
    }
}

/**
 *  返回cell的宽度
 */
- (CGFloat)cellWidth
{
    NSUInteger totalColumns = [self totalColumns];
    CGFloat leftMargin = [self marginWithType:ZZWaterflowViewMarginTypeLeft];
    CGFloat columnMargin = [self marginWithType:ZZWaterflowViewMarginTypeColumn];
    CGFloat rightMargin = [self marginWithType:ZZWaterflowViewMarginTypeRight];
    return (ZZScreenW - leftMargin - rightMargin - (totalColumns - 1) * columnMargin) / totalColumns;
}

/**
 *  返回cell间的各种间距
 */
- (CGFloat)marginWithType:(ZZWaterflowViewMarginType)type
{
    if ([self.waterDelegate respondsToSelector:@selector(waterflowView:marginType:)]) {
        return [self.waterDelegate waterflowView:self marginType:type];
    } else {
        return ZZDefaultCellMargin;
    }
}

/**
 *  返回一共多少列
 */
- (NSUInteger)totalColumns
{
    if ([self.waterDelegate respondsToSelector:@selector(numberOfColumnsInWaterflowView:)]) {
        return [self.waterDelegate numberOfColumnsInWaterflowView:self];
    } else {
        return ZZDefaultTotalColumns;
    }
}

@end
