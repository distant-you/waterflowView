//
//  ZZProduct.h
//  waterflowView
//
//  Created by parrow tech on 16/1/15.
//  Copyright © 2016年 YX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZZProduct : NSObject

@property (nonatomic, strong) NSNumber *w;
@property (nonatomic, strong) NSNumber *h;
@property (nonatomic, copy) NSString *price;
@property (nonatomic, copy) NSString *img;

@end
